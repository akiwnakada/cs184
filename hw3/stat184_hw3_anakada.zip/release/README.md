# CartPole Control using Natural Policy Gradients

## Usage

* You can install in requirements.txt by running
```
  $ pip install -r requirements.txt
```
all what you need is numpy, openai gym, and sklearn. We 
specifically use gym version 0.25.0. Make sure you have 
this version else the code may not run.

* to generate the plot once you have completed everything, run
```
  $ python train.py
```
